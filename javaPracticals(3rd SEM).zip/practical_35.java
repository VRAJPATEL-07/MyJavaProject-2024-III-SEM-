public class practical_35 {
    public static void main(String[] args) {
        Thread firsThread = new Thread(new Runnable(){
            @Override
            public void run(){
                System.out.println("Fisrt Thread is running with priority " + Thread.currentThread().getPriority());
            }
        },"FIRST");
        firsThread.setPriority(3);

        Thread secondThread = new Thread(new Runnable(){
            @Override
            public void run(){
                System.out.println("Second Thread is running with priority " + Thread.currentThread().getPriority());
            }
        },"SECOND");
        
        Thread thirdThread = new Thread(new Runnable(){
            @Override
            public void run(){
                System.out.println("Third Thread is running with priority " + Thread.currentThread().getPriority());
            }
        },"THIRD");
        firsThread.setPriority(7);

        firsThread.start();
        secondThread.start();
        thirdThread.start();
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
