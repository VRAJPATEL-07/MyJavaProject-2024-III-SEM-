import java.util.*;
class practical_5
{
    public static void main(String args[])
    {
        
        Scanner sc = new Scanner(System.in);
        Random r = new Random();
        int r1,result=0;
        r1 = r.nextInt(100);
        System.out.print("Guessed random number is: "+r1);
        System.out.print("\n");
        do{
        System.out.print("Guess the random number: ");
        result = sc.nextInt();
        
      
        if(result == r1)
        {
            System.out.println("You have guessed right.");
        }
        else if(result > r1)
        {
            System.out.println("Too high.");
        }
        else
        {
            System.out.println("Too low.");
        }
        }while(result != r1);
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}


