class practical_1
{
    public static void main(String args[])
    {
       int age=25;
       System.out.println("sam age is "+age);
    }
}
