//Java Program to Generate User-Defined Exception using throw and throws
class AgeRestrictionException extends Exception {
    public AgeRestrictionException(String message) {
        super(message);
    }
}

public class practical_25_1 {

    public static void checkAge(int age) throws AgeRestrictionException {
        if (age < 18) {
            
            throw new AgeRestrictionException("Access denied - You must be at least 18 years old.");
        } else {
            System.out.println("Access granted - You are old enough!");
        }
    }

    public static void main(String[] args) {
        try {
            checkAge(18); 
        } catch (AgeRestrictionException e) {
            System.out.println("Caught the exception: " + e.getMessage());
        }
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}


