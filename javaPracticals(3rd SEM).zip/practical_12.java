
public class practical_12
{
    class employee{
        private String fname;
        private String lname;
        private double salary;

        public employee(String fname,String lname, double salary )
        {
            this.fname = fname;
            this.lname = lname;
            this.salary = salary;
        }

        public void monthlysal(double sal)
        {
            if(sal > 0.0)
            {
                this.salary=sal;
            }else{
                this.salary=0.0;
            }
        }

        public double yearly(double sal)
        {
            return (sal*12);
        }

        public double increase(double sal)
        {
            return (sal*12)+(sal*=0.1);
        }
    };
    public  void main(String args[])
    {
       employee obj1 = new employee("vraj","patel",400000);
       System.out.println("obj1 fname:"+obj1.fname);
       System.out.println("obj1 lname:"+obj1.lname);
       System.out.println("obj1 salary:"+obj1.salary);
       System.out.println("**********************************************************");
       employee obj2 = new employee("vaibhav","tandel",500000);
       System.out.println("obj2 fname:"+obj2.fname);
       System.out.println("obj2 lname:"+obj2.lname);
       System.out.println("obj2 salary:"+obj2.salary);
       System.out.println("**********************************************************");
       System.out.println("obj1 yearly salary :"+obj1.yearly(obj1.salary));
       System.out.println("obj2 yearly salary :"+obj2.yearly(obj2.salary));
       System.out.println("**********************************************************");
       System.out.println("obj1 increased salary :"+obj1.increase(obj1.salary));
       System.out.println("obj2 increased salary :"+obj2.increase(obj2.salary));
       System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
    
}
