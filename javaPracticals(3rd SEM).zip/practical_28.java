import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class practical_28 {
    public static void main(String[] args) {
        // Check if the word and file name are provided
        if (args.length != 2) {
            System.out.println("Usage: java WordSearcher <word> <filename>");
            return;
        }

        String wordToSearch = args[0];
        String fileName = args[1];

        // Count the occurrences of the word in the specified file
        Integer count = countWordInFile(wordToSearch, fileName);
        
        if (count != null) {
            System.out.println("The word '" + wordToSearch + "' appears " + count + " times in " + fileName);
        }
    }

    private static Integer countWordInFile(String word, String fileName) {
        int count = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line into words and count occurrences
                String[] words = line.split("\\W+"); // Split on non-word characters
                for (String w : words) {
                    if (w.equalsIgnoreCase(word)) {
                        count++;
                    }
                }
            }
            return count;
        } catch (IOException e) {
            System.err.println("Error reading file '" + fileName + "': " + e.getMessage());
            return null;
        }
    }
}

