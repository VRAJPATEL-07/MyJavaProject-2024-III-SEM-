import java.util.Random;

class RandomNumberGenerator extends Thread {
    private SharedNumber sharedNumber;

    public RandomNumberGenerator(SharedNumber sharedNumber) {
        this.sharedNumber = sharedNumber;
    }

    @Override
    public void run() {
        Random random = new Random();
        while (true) {
            int number = random.nextInt(100); // Generate random number between 0 and 99
            sharedNumber.setNumber(number);

            try {
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class SquareCalculator extends Thread {
    private SharedNumber sharedNumber;

    public SquareCalculator(SharedNumber sharedNumber) {
        this.sharedNumber = sharedNumber;
    }

    @Override
    public void run() {
        while (true) {
            synchronized (sharedNumber) {
                int number = sharedNumber.getNumber();
                if (number % 2 == 0) {
                    System.out.println("Square of " + number + " is : " + (number * number));
                }
            }
            try {
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class CubeCalculator extends Thread {
    private SharedNumber sharedNumber;

    public CubeCalculator(SharedNumber sharedNumber) {
        this.sharedNumber = sharedNumber;
    }

    @Override
    public void run() {
        while (true) {
            synchronized (sharedNumber) {
                int number = sharedNumber.getNumber();
                if (number % 2 != 0) {
                    System.out.println("Cube of " + number + " is : " + (number * number * number));
                }
            }
            try {
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class SharedNumber {
    private int number;

    public synchronized void setNumber(int number) {
        this.number = number;
    }

    public synchronized int getNumber() {
        return number;
    }
}

public class practical_33 {
    public static void main(String[] args) {
        SharedNumber sharedNumber = new SharedNumber();

        RandomNumberGenerator generator = new RandomNumberGenerator(sharedNumber);
        SquareCalculator squareCalculator = new SquareCalculator(sharedNumber);
        CubeCalculator cubeCalculator = new CubeCalculator(sharedNumber);

        generator.start();
        squareCalculator.start();
        cubeCalculator.start();
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
