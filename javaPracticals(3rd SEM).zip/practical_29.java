import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class practical_29 {
    public static void main(String[] args) {
        // Check if source and destination filenames are provided
        if (args.length != 2) {
            System.out.println("Usage: java FileCopier <source file> <destination file>");
            return;
        }

        String sourceFile = args[0];
        String destinationFile = args[1];

        // Copy data from source file to destination file
        copyFile(sourceFile, destinationFile);
    }

    private static void copyFile(String sourceFile, String destinationFile) {
        try (FileInputStream in = new FileInputStream(sourceFile);
             FileOutputStream out = new FileOutputStream(destinationFile)) {

            byte[] buffer = new byte[1024];
            int bytesRead;

            // Read from source and write to destination
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }

            System.out.println("File copied successfully from " + sourceFile + " to " + destinationFile);
        } catch (IOException e) {
            System.err.println("Error occurred: " + e.getMessage());
        }
    }
}
