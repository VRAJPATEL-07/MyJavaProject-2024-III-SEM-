import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class practical_30 {
    public static void main(String[] args) {
        // Use BufferedReader to read input from console
        try (BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
             BufferedWriter fileWriter = new BufferedWriter(new FileWriter("output.txt"))) {

            System.out.println("Enter text to write to the file (type 'exit' to finish):");

            String inputLine;
            while (!(inputLine = consoleReader.readLine()).equalsIgnoreCase("exit")) {
                // Write input to the file
                fileWriter.write(inputLine);
                fileWriter.newLine(); // Add a new line
            }

            System.out.println("Data written to output.txt successfully.");

        } catch (IOException e) {
            System.err.println("Error occurred: " + e.getMessage());
        }

        // Read from the file using FileReader and BufferedReader
        System.out.println("\nReading from output.txt:");
        try (BufferedReader fileReader = new BufferedReader(new FileReader("output.txt"))) {
            String line;
            while ((line = fileReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
}
