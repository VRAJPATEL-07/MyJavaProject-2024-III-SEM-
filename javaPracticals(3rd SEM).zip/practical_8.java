import java.util.*;

class practical_8
{
    public static void main(String args[])
    {
       Scanner sc = new Scanner(System.in);
       System.out.print("Enter a string: ");
       String str = sc.nextLine();
       
       for(int i=0;i<str.length();i++)
       {
        System.out.print(str.charAt(i)); 
        System.out.print(str.charAt(i)); 
       }
       System.out.print("\n"); 
       System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}

