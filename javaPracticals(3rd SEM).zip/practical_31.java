public class practical_31 extends Thread{
    @Override
    public void run(){
        System.out.println("Helllo World!!");
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }

    public static void main(String[] args) {
        practical_31 thread = new practical_31();
        thread.start();
    }
}
