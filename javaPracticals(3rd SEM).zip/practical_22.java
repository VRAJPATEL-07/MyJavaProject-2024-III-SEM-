interface Shape 
{
    double getArea();
    String getColor();
    
    default void displayInfo() {
        System.out.println("Shape Color: " + getColor());
        System.out.println("Shape Area: " + getArea());
    }
}
class Circle implements Shape {
    private double radius;
    private String color;

    public Circle(double radius, String color) 
    {
        this.radius = radius;
        this.color = color;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public String getColor() {
        return color;
    }
}

class Rectangle implements Shape {
    private double length;
    private double width;
    private String color;

    public Rectangle(double length, double width, String color) {
        this.length = length;
        this.width = width;
        this.color = color;
    }

    @Override
    public double getArea() {
        return length * width;
    }

    @Override
    public String getColor() {
        return color;
    }
}

class Sign {
    private Shape shape;
    private String text;

    public Sign(Shape shape, String text) 
    {
        this.shape = shape;
        this.text = text;
    }

    public void displaySignInfo() 
    {
        shape.displayInfo();
        System.out.println("Sign Text: " + text);
    }
}

public class practical_22 {
    public static void main(String[] args) {
        
        Circle circle = new Circle(5.0, "Red");
        Rectangle rectangle = new Rectangle(4.0, 6.0, "Blue");
        
        Sign circleSign = new Sign(circle, "Welcome to the Campus Center");
        
        Sign rectangleSign = new Sign(rectangle, "Library Hours: 9 AM - 5 PM");
        
        System.out.println("Circle Sign Information:");
        circleSign.displaySignInfo();
        
        System.out.println("\nRectangle Sign Information:");
        rectangleSign.displaySignInfo();
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
