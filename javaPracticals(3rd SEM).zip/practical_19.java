class Shape 
{
    void s1() 
    {
        System.out.println("This is a class shape.");
    }
}

class Rectangle extends Shape 
{
    void r1() 
    {
        System.out.println("This is a rectangular shape.");
    }
}

class Circle extends Shape 
{
    void c1() 
    {
        System.out.println("This is a circle shape.");
    }
}

class Square extends Rectangle 
{
    void s2() 
    {
        System.out.println("Square is a rectangle.");
    }
}

class practical_19 {
    public static void main(String args[]) {
        Square s = new Square();
        s.s2();
        s.s1();
        s.r1();
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
