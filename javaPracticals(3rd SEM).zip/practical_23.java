import java.util.*;

public class practical_23 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            
            System.out.print("Enter the value of X: ");
            int x = sc.nextInt();

            System.out.print("Enter the value of y: ");
            int y = sc.nextInt();

            int result = x / y;

            System.out.println("the Division of "+x+" / "+y+" is : "+result);

        } catch (InputMismatchException e) {
            System.out.println("ERROR: Please, Enter the valid integers.");
        }catch(ArithmeticException e){
            System.out.println("ERROR: Division by zero is not Allowed.");
        }finally{
            sc.close();
        }
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
