import java.util.Scanner;

class practical_7 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the Array's length: ");
        int n = sc.nextInt();
        
        int arr[] = new int[n];
       
        System.out.print("Enter the Array: ");
        for(int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        int flag = 0;
        for(int i = 0; i < n; i++) {
            if(arr[i] == 9) {
                flag++;
            }
        }
        
        if(flag == 0) {
            System.out.println("There's no 9 in the Array.");
        } else {
            System.out.println("There's " + flag + " time(s) 9 in the Array.");
        }
        
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
