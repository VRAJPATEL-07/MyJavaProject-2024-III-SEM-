import java.util.Scanner;

public class practical_10 {
        public static String reverseString(String str) {
        StringBuilder reversed = new StringBuilder();
        for (int i = str.length() - 1; i >= 0; i--) {
            reversed.append(str.charAt(i));
        }
        return reversed.toString();
    }

    public static String sortString(String str) {
        char[] charArray = str.toCharArray();
        for (int i = 0; i < charArray.length - 1; i++) {
            for (int j = i + 1; j < charArray.length; j++) {
                if (charArray[i] > charArray[j]) {
                    char temp = charArray[i];
                    charArray[i] = charArray[j];
                    charArray[j] = temp;
                }
            }
        }
        return new String(charArray);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = "CHARUSAT UNIVERSITY";

        int choice;
        do {
            System.out.println("\n:::::::::MENU:::::::::");
            System.out.println("1. FIND THE LENGTH OF STRING.");
            System.out.println("2. Replace 'H' by FIRST LETTER OF YOUR NAME.");
            System.out.println("3. LOWERCASE OF THE STRING.");
            System.out.println("4. UPPERCASE OF THE STRING.");
            System.out.println("5. REVERSE THE STRING.");
            System.out.println("6. SORT THE STRING.");
            System.out.println("7. EXIT.");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    int length = str.length();
                    System.out.println("String length is: " + length);
                    break;
                case 2:
                    char firstLetter = 'V'; 
                    String modifiedStr = str.replace('H', firstLetter);
                    System.out.println("Modified string after replacing 'H': " + modifiedStr);
                    break;
                case 3:
                    String lowercaseStr = str.toLowerCase();
                    System.out.println("String in Lowercase is: " + lowercaseStr);
                    break;
                case 4:
                    String uppercaseStr = str.toUpperCase();
                    System.out.println("String in Uppercase is: " + uppercaseStr);
                    break;
                case 5:
                    String reversedStr = reverseString(str);
                    System.out.println("String in Reverse is: " + reversedStr);
                    break;
                case 6:
                    String sortedStr = sortString(str);
                    System.out.println("Sorted String is: " + sortedStr);
                    break;
                case 7:
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 7);

        sc.close();
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
