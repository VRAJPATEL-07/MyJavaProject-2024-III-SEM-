class Degree
{
    void getDegree()
    {
        System.out.println("I got a degree.");
    }
}

class Undergraduate extends  Degree
{
    void getDegree()
    {
        super.getDegree();
        System.out.println("I am an Undergraduate.");
    }
}

class Postgraduate extends  Degree
{
    
    void getDegree()
    {
        super.getDegree();
        System.out.println("I am an Postgraduate.");
    }
    
}

class practical_21
{
    public static void main(String args[])
    {
        Degree d = new Degree();
        Undergraduate u = new Undergraduate();
        Postgraduate p = new Postgraduate();

        d.getDegree();
        System.out.println("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        u.getDegree();
        System.out.println("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        p.getDegree();
       System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
