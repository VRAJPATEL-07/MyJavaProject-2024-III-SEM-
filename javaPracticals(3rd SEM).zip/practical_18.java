import java.util.Scanner;

class Rectangle {
    private double length;
    private double breadth;

    Rectangle() {
        length = 0.0;
        breadth = 0.0;
    }

    public void get() {
        Scanner obj = new Scanner(System.in);
        System.out.print("Enter Rectangle's length: ");
        length = obj.nextDouble();
        System.out.print("Enter Rectangle's breadth: ");
        breadth = obj.nextDouble();
    }

    public void put() {
        System.out.println("Rectangle's length: " + length);
        System.out.println("Rectangle's breadth: " + breadth);
    }

    public void area() {
        double area = length * breadth;
        System.out.println("Rectangle's area is: " + area);
    }

    public void perimeter() {
        double perimeter = 2 * (length + breadth);
        System.out.println("Rectangle's perimeter is: " + perimeter);
    }
}

class Square extends Rectangle {
    private double side;

    Square() {
        side = 0.0;
    }

    public void getSide() {
        Scanner obj = new Scanner(System.in);
        System.out.print("Enter Square's side: ");
        side = obj.nextDouble();
    }

    public void putSide() {
        System.out.println("Square's side: " + side);
    }

    public void area() {
        double area = side * side;
        System.out.println("Square's area is: " + area);
    }

    public void perimeter() {
        double perimeter = 4 * side;
        System.out.println("Square's perimeter is: " + perimeter);
    }
}

public class practical_18 {
    public static void main(String[] args) {
        Rectangle r = new Rectangle();
        Square s = new Square();

        System.out.println("Enter Rectangle's details:");
        r.get();
        r.put();
        r.area();
        r.perimeter();
        System.out.println("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        System.out.println("\n");
        System.out.println("Enter Square's details:");
        s.getSide();
        s.putSide();
        s.area();
        s.perimeter();
        System.out.println("\n");
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
