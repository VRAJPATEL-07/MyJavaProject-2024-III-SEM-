public class practical_34 {
    public static void main(String[] args) {
        Thread incrementThread = new Thread(new Runnable(){
            @Override
            public void run(){
                try {
                    int value = 0;
                    value++;
                    Thread.sleep(1000);
                    System.out.println("Value after one second: " + value);
                } catch(InterruptedException e){
                    System.err.println("There was interrupted: " + e.getMessage());
                }
            }
        });
        incrementThread.start();
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
