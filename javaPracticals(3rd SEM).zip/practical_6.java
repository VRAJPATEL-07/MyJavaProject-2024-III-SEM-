import java.util.Scanner;

public class practical_6 {
    
    public static String repeatFirstChars(String s, int n) {
        int len = s.length();

        String firstChars = s.substring(0, Math.min(n, len));

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < n; i++) {
            result.append(firstChars);
        }
        
        return result.toString();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter your string: ");
        String str = sc.nextLine();
        
        System.out.print("Enter the Number: ");
        int num = sc.nextInt();
        
        String result = repeatFirstChars(str, num);
        
        System.out.println("String is: " + result);
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
