class sum implements Runnable{
    private int[] numbers;
    private int start;
    private int end;
    private int partialsum;

    public sum(int[] numbers, int start, int end){
        this.numbers = numbers;
        this.start = start;
        this.end = end;
        this.partialsum = 0;
    }

    @Override
    public void run(){
        for(int i=start; i<end; i++){
            partialsum += numbers[i];
        }
    }

    public long getPartialSum(){
        return partialsum;
    }
}

public class practical_32 {
    private static final String[] args = null;
    public static void main(String[] args) {
        if(args.length != 2) {
            System.out.println("Usage: java SumWithThreads <N> <numThreads>");
            return;
        }
        int N = Integer.parseInt(args[0]);
        int numThreads = Integer.parseInt(args[1]);
    
        int[] numbers = new int[N];
        for(int i=0; i<N; i++){
            numbers[i] = i+1;
        }
    
        sum[] tasks = new sum[numThreads];
        Thread[] threads = new Thread[numThreads];
        
        int chunkSize = N / numThreads;
        int remainder  = N % numThreads;
    
        int start = 0, end;
        for(int i=0; i<numThreads; i++){
            end = start + chunkSize + (i < remainder ? 1 : 0);
            tasks[i] = new sum(numbers, start, end);
            threads[i] = new Thread(tasks[i]);
            threads[i].start();
            start = end;
        }
    
        int finalSum = 0;
        try{
            for(int i=0; i<numThreads; i++){
                threads[i].join();
                finalSum += tasks[i].getPartialSum();
            } 
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    
        System.out.println("Final sum = " + finalSum);
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }

}
