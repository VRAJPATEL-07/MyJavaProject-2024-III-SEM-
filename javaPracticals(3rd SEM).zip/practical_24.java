import java.util.*;

public class practical_24 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            
            System.out.print("Enter the value of X: ");
            int x = sc.nextInt();

            System.out.print("Enter the value of y: ");
            int y = sc.nextInt();

            if(y == 0){
                throw new ArithmeticException("Division by zero is Not Allowed.");
            }

            int result = x / y;

            System.out.println("the Division of "+x+" / "+y+" is : "+result);

        } catch (InputMismatchException e) {
            System.out.println("ERROR: Please, Enter the valid integers.");
        }catch(ArithmeticException e){
            System.out.println("Caught an exception: "+e.getMessage());
        }finally{
            sc.close();
        }
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
