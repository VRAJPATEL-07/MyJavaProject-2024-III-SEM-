import java.util.*;

public class Practical_13 {
    class Date {
    private int day;
    private int month;
    private int year;

    public Date() {
        this.day = 0;
        this.month = 0;
        this.year = 0;
    }

    public void set(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public int getDay() {
        return this.day;
    }

    public int getMonth() {
        return this.month;
    }

    public int getYear() {
        return this.year;
    }

    public void display() {
        System.out.println(day + "/" + month + "/" + year);
    }
}
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter date (DD MM YYYY):");
        int D = sc.nextInt();
        int M = sc.nextInt();
        int Y = sc.nextInt();

        Date date1 = new Date();
        date1.set(D, M, Y);

        date1.display();
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
        
        sc.close();
    }
}
