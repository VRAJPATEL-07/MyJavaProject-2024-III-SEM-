import java.util.*;

class practical_11
{
    public static void main(String args[])
    {
       Scanner sc = new Scanner(System.in);
       System.out.print("Enter pound: ");
       double pound = sc.nextDouble();
       double rupees;
       rupees = pound * (108.70);
       System.out.println("Your pound in ruees is:"+rupees);
       System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
