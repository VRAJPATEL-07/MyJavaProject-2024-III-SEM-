import java.util.Scanner;

class complex1 {
    private double imaginary1, imaginary2;
    private double real1, real2;

    public void getdata() {
        Scanner obj = new Scanner(System.in);

        System.out.println("Enter Real number 1 :: ");
        real1 = obj.nextDouble();
        System.out.print("Enter Imaginary number 1 :: ");
        imaginary1 = obj.nextDouble();
        System.out.println("Enter Real number 2 :: ");
        real2 = obj.nextDouble();
        System.out.print("Enter Imaginary number 2 :: ");
        imaginary2 = obj.nextDouble();

    }

    public void Addition() {
        double r, i;
        r = (real1 + real2);
        i = (imaginary1 + imaginary2);

        System.out.println("Sum of Two Complex Number : " + r + "+" + i + "i");

    }

    public void Difference() {
        double r, i;
        r = (real1 - real2);
        i = (imaginary1 - imaginary2);
        System.out.println("Difference of Two Complex Number : " + r + "+" + i + "i");

    }

    public void Product() {
        double r, i;
        r = ((real1 * real2) - (imaginary1 * imaginary2));
        i = ((real1 * imaginary2) + (imaginary1 * real2));
        System.out.println("Product of Two Complex Number : " + r + "+" + i + "i");

    }
}

public class practical_15 
{

    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        complex1 c1 = new complex1();

        c1.getdata();
        System.out.println(":::::::::Menu:::::::::");
        System.out.println("1. Sum Of Two Complex Number");
        System.out.println("2. Difference of Two Complex Number");
        System.out.println("3. Product of Two Complex Number");
        System.out.println("::::::::::::::::::::::::");
        System.out.print("Enter Your Choise :: ");
        int a = obj.nextInt();

        switch (a) {

            case 1:

                c1.Addition();

                break;

            case 2:

                c1.Difference();

                break;

            case 3:

                c1.Product();

                break;

            default:

                System.out.println("Enter Valid Choise!!");

        }
        System.out.println(":::::23DIT054:::::");
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }

}
