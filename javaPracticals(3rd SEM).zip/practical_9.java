import java.util.*;

class practical_9
{
    public static String sortString(String inputString)
    {
        char tempArray[] = inputString.toCharArray();
        Arrays.sort(tempArray);
        return new String(tempArray);
    }
    public static void main(String args[])
    {
       Scanner sc = new Scanner(System.in);
       System.out.print("Enter a string: ");
       String str = sc.nextLine();
       int choice;
       do{
       System.out.println("\n:::::::::MENU:::::::::");
       System.out.println("1. FIND THE LENGTH OF STRING.");
       System.out.println("2. LOWERCASE OF THE STRING.");
       System.out.println("3. UPPERCASE OF THE STRING.");
       System.out.println("4. REVERSE THE STRING.");
       System.out.println("5. SORT THE STRING.");
       System.out.println("6. CHECK WHETER STRING IS PALINDROME OR NOT.");
       System.out.println("7. EXIT.");
       System.out.print("Enter your choice: ");
       choice = sc.nextInt();

       switch(choice)
       {
        case 1:
        {
            int length;
            length = str.length();
            System.out.println("String length is: "+length);
            break;
        }
        case 2:
        {
            String s;
            s = str.toLowerCase();
            System.out.println("String in Lowercase is: "+s);
            break;
        }
        case 3:
        {
            String s;
            s = str.toUpperCase();
            System.out.println("String in Uppercase is: "+s);
            break;
        }
        case 4:
        {
            char ch;
            String nstr = " ";
            for (int i=0; i<str.length(); i++)
            {
              ch= str.charAt(i);
              nstr= ch+nstr;
            }
            System.out.println("String in Reverse is: "+nstr);
            break;
        }
        case 5:
        {
            String s;
            s = sortString(str);
            System.out.println("String in Lowercase is: "+s);
            break;
        }
        case 6:
        {
            char ch;
            String nstr = " ";
            for (int i=0; i<str.length(); i++)
            {
              ch= str.charAt(i);
              nstr= ch+nstr;
            }
            System.out.println("String in Reverse is: "+nstr);

            if(str==nstr)
            {
                System.out.println("String is  palindrome.");
            }else
            {
                System.out.println("String isn't palindrome.");
            }
            break;
        }
        case 7:
        {
            System.out.println("Exiting program.");
            break;
        }
        default:
        {
            System.out.println("Invalid choice.");
        }
       }
      }while(choice != 7);
      System.out.println("::::::::::23DIT056_VRAJ::::::::::"); 
    }
}
 

// import java.util.Scanner;

// class practical_9 {
//     public static void identifyPalindromes(String str) {
//         System.out.println("Potential palindromes in the string:");
//         for (int i = 0; i < str.length(); i++) {
//             for (int j = i + 2; j <= str.length(); j++) {
//                 String substring = str.substring(i, j);
//                 if (isPalindrome(substring)) {
//                     System.out.println("- " + substring);
//                 }
//             }
//         }
//     }

//     public static boolean isPalindrome(String str) {
//         int left = 0;
//         int right = str.length() - 1;
//         while (left < right) {
//             if (str.charAt(left) != str.charAt(right)) {
//                 return false;
//             }
//             left++;
//             right--;
//         }
//         return true;
//     }

//     public static String bubbleSort(char[] arr) {
//         int n = arr.length;
//         for (int i = 0; i < n - 1; i++) {
//             for (int j = 0; j < n - i - 1; j++) {
//                 if (arr[j] > arr[j + 1]) {
//                     char temp = arr[j];
//                     arr[j] = arr[j + 1];
//                     arr[j + 1] = temp;
//                 }
//             }
//         }
//         return new String(arr);
//     }

//     public static void main(String args[]) {
//         Scanner sc = new Scanner(System.in);
//         System.out.print("Enter a string: ");
//         String str = sc.nextLine();
//         int choice;
//         do {
//             System.out.println("\n:::::::::MENU:::::::::");
//             System.out.println("1. FIND THE LENGTH OF STRING.");
//             System.out.println("2. LOWERCASE AND UPPERCASE OF THE STRING.");
//             System.out.println("3. REVERSE THE STRING.");
//             System.out.println("4. SORT THE STRING.");
//             System.out.println("5. CHECK WHETHER STRING IS PALINDROME OR NOT.");
//             System.out.println("6. EXIT.");
//             System.out.print("Enter your choice: ");
//             choice = sc.nextInt();
//             sc.nextLine(); // Consume newline

//             switch (choice) {
//                 case 1: {
//                     int count = str.length();
//                     System.out.println("Length of the string is: " + count);
//                     break;
//                 }
//                 case 2: {
//                     char[] chars = str.toCharArray();
//                     System.out.print("String in Lowercase is: ");
//                     for (int i = 0; i < chars.length; i++) {
//                         if (chars[i] >= 'A' && chars[i] <= 'Z') {
//                             chars[i] = (char) (chars[i] + 32);
//                         }
//                         System.out.print(chars[i]);
//                     }
//                     System.out.println();

//                     System.out.print("String in Uppercase is: ");
//                     for (int i = 0; i < chars.length; i++) {
//                         if (chars[i] >= 'a' && chars[i] <= 'z') {
//                             chars[i] = (char) (chars[i] - 32);
//                         }
//                         System.out.print(chars[i]);
//                     }
//                     System.out.println();
//                     break;
//                 }
//                 case 3: {
//                     String nstr = "";
//                     for (int i = str.length() - 1; i >= 0; i--) {
//                         nstr += str.charAt(i);
//                     }
//                     System.out.println("String in Reverse is: " + nstr);
//                     break;
//                 }
//                 case 4: {
//                     char[] arr = str.toCharArray();
//                     String sortedString = bubbleSort(arr);
//                     System.out.println("Sorted String is: " + sortedString);
//                     break;
//                 }
//                 case 5: {
//                     boolean isPalin = isPalindrome(str);
//                     if (isPalin) {
//                         System.out.println("String is a palindrome.");
//                     } else {
//                         System.out.println("String isn't a palindrome.");
//                     }
//                     break;
//                 }
//                 case 6: {
//                     System.out.println("Exiting program.");
//                     break;
//                 }
//                 default: {
//                     System.out.println("Invalid choice.");
//                 }
//             }
//         } while (choice != 6);
//     }
// }
