import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class practical_29_2 {
    public static void main(String[] args) {
        // Sample list of strings
        List<String> strings = Arrays.asList("Banana", "Apple", "Orange", "Grapes", "Mango");

        // Sort in ascending order
        List<String> sortedAscending = strings.stream()
                .sorted()
                .collect(Collectors.toList());
        
        System.out.println("Sorted in Ascending Order: " + sortedAscending);

        // Sort in descending order
        List<String> sortedDescending = strings.stream()
                .sorted((s1, s2) -> s2.compareTo(s1)) // or use Comparator.reverseOrder()
                .collect(Collectors.toList());

        System.out.println("Sorted in Descending Order: " + sortedDescending);
    }
}
