import java.util.Scanner;

public class practical_4 
{
   public static void main(String args[])
   {
     int size,temp;
     double bill=0;
     Scanner sc = new Scanner(System.in);

     System.out.print("Enter the No. of products: ");
     size = sc.nextInt();
     int[] p_code = new int[size];
     int[] p_price = new int[size];
     for(int i=0 ; i<size ; i++)
     {
        System.out.print("Enter the code for product " + (i+1) + ": ");
        temp = sc.nextInt();
        p_code[i] = temp;
     }

     for(int i=0 ; i<size ; i++)
     {
        System.out.println("Enter the price for product " + (i+1) + " : ");
        temp = sc.nextInt();
        p_price[i] = temp;
     }

      for(int i=0; i<size; i++)
      {
        switch(p_code[i])
        {

           case 1:
           {
                bill += (p_price[i]*(p_price[i]*0.08));
                break;
           }
           case 2:
           {
                bill += (p_price[i]*(p_price[i]*0.08));
                break;
           }
           case 3:
           {
                bill += (p_price[i]*(p_price[i]*0.08));
                break;
           }
           case 4:
           {
                bill += (p_price[i]*(p_price[i]*0.08));
                break;
           }
           case 5:
           {
                bill += (p_price[i]*(p_price[i]*0.08));
                break;
           }
           default:
           {
              System.out.println("Your choice is invalid.");  
           }
        }
      }
        System.out.println("Your bill is:"+bill); 
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
   }    
}
