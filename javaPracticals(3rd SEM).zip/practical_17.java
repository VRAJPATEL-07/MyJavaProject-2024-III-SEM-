import java.util.Scanner;

class Member {
    private String name;
    private int age;
    private long phone_no;
    private String address;
    private double salary;

    Scanner obj = new Scanner(System.in);

    public void get() {
        System.out.println("Enter Member name: ");
        name = obj.nextLine();
        System.out.println("Enter Member age: ");
        age = obj.nextInt();
        System.out.println("Enter Member phone_no: ");
        phone_no = obj.nextLong();
        obj.nextLine(); // Consume newline
        System.out.println("Enter Member address: ");
        address = obj.nextLine();
        System.out.println("Enter Member salary: ");
        salary = obj.nextDouble();
        obj.nextLine(); // Consume newline
    }

    public void put() {
        System.out.println("Member's name: " + name);
        System.out.println("Member's age: " + age);
        System.out.println("Member's phone_no: " + phone_no);
        System.out.println("Member's address: " + address);
        System.out.println("Member's salary: " + salary);
    }

    void printSalary() {
        System.out.println("The Salary of member is: " + salary);
    }
}

class Employee extends Member {
    private String specialization;
    private String department;

    Scanner obj = new Scanner(System.in);

    public void getE() {
        System.out.println("Enter Employee's specialization: ");
        specialization = obj.nextLine();
        System.out.println("Enter Employee's department: ");
        department = obj.nextLine();
    }

    public void putE() {
        System.out.println("Employee's specialization: " + specialization);
        System.out.println("Employee's department: " + department);
    }
}

class Manager extends Member {
    private String specialization;
    private String department;

    Scanner obj = new Scanner(System.in);

    public void getM() {
        System.out.println("Enter Manager's specialization: ");
        specialization = obj.nextLine();
        System.out.println("Enter Manager's department: ");
        department = obj.nextLine();
    }

    public void putM() {
        System.out.println("Manager's specialization: " + specialization);
        System.out.println("Manager's department: " + department);
    }
}

class practical_17 {
    public static void main(String args[]) {
        Employee e = new Employee();
        System.out.println("Enter Employee's details: ");
        e.get();
        e.getE();

        Manager ma = new Manager();
        System.out.println("Enter Manager's details: ");
        ma.get();
        ma.getM();

        System.out.println("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        System.out.println("Employee's details: ");
        e.put();
        e.putE();
        e.printSalary();
        System.out.println("\n");
        System.out.println("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        System.out.println("Manager's details: ");
        ma.put();
        ma.putM();
        ma.printSalary();
        System.out.println("\n");
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
