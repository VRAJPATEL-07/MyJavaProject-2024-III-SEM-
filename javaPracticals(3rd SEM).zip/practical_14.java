import java.util.Scanner;

class Area {
    private double len;
    private double wid;

    public Area() {
        this.len = 0.0;
        this.wid = 0.0;
    }

    public void set(double len, double wid) {
        this.len = len;
        this.wid = wid;
    }

    public double getLen() {
        return this.len;
    }

    public double getWid() {
        return this.wid;
    }

    public double calculateArea() {
        return this.len * this.wid;
    }
}

public class Practical_14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter length: ");
        double length = sc.nextDouble();
        System.out.print("Enter width: ");
        double width = sc.nextDouble();

        Area a = new Area();
        a.set(length, width);

        double area = a.calculateArea();
        System.out.println("Area is: " + area);
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
        
        sc.close();
    }
}
