//Java Program that Differentiates Checked and Unchecked Exceptions
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class practical_25_2 {

   
    public static void readFile(String fileName) throws FileNotFoundException {
        File file = new File(fileName);
        FileReader fileReader = new FileReader(file); 
    }

  
    public static void divide(int a, int b) {
        int result = a / b; 
        System.out.println("Result: " + result);
    }

    public static void main(String[] args) {
       
        try {
            readFile("nonexistentfile.txt");
        } catch (FileNotFoundException e) {
            System.out.println("Caught checked exception: " + e.getMessage());
        }

        try {
            Thread.sleep(-1);
        } catch (InterruptedException | IllegalArgumentException e) {
            System.out.println("Caught checked exception: " + e.getMessage());
        }

        try {
            divide(10, 0);
        } catch (ArithmeticException e) {
            System.out.println("Caught unchecked exception: " + e.getMessage());
        }

        try {
            int[] arr = new int[5];
            arr[10] = 50;
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught unchecked exception: " + e.getMessage());
        }
        System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
