class parent
{
    void p1()
    {
        System.out.println("This is parent class.");
    }
}

class child extends  parent
{
    void c1()
    {
        System.out.println("This is child class.");
    }
}

class practical_16
{
    public static void main(String args[])
    {
       parent p = new parent();
       p.p1();

       child c = new child();
       c.c1();

       c.p1();
       System.out.println("::::::::::23DIT056_VRAJ::::::::::");
    }
}
