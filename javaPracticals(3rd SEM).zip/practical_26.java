import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class practical_26 {
    public static void main(String[] args) {
        // Check if any files were provided
        if (args.length == 0) {
            System.out.println("No files specified.");
            return;
        }

        // Process each file provided on the command line
        for (String fileName : args) {
            countLinesInFile(fileName);
        }
    }

    private static void countLinesInFile(String fileName) {
        int lineCount = 0;

        // Try to read the file and count lines
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            while (reader.readLine() != null) {
                lineCount++;
            }
            System.out.println(fileName + ": " + lineCount + " lines");
        } catch (IOException e) {
            System.err.println("Error reading file '" + fileName + "': " + e.getMessage());
        }
    }
}
